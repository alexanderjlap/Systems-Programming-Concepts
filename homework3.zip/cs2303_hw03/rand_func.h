#ifndef RAND_FUNCS_H
#define RAND_FUNCS_H

/* function prototypes */

int randInt();

int randCharInt();

char *randFill();

#endif
