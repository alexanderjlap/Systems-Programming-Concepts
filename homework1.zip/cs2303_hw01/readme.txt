# CS2303 Homework 1 By Alexander Lap

# num.c - This program reads a number from the command line and prints the number. For example, use ./num [1] which makes: 

The number you entered was 1

# grade.c - This program calculates the GPA of the grade(s) that have been listed. For example, use ./grades 95 85 25 which makes: 

Grades entered: 3
Grades: 95
Grades: 85
Grades: 25
GPA: 68.333333
Max: 95
Min: 25

Enter at least 20 inputs will check that amount and only produce the first 20 inputs. For example, use ./grades 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 which makes:

Too many grades entered! Shortened to 20 grades.
Grades entered: 20
Grade: 1
Grade: 2
Grade: 3
Grade: 4
Grade: 5
Grade: 6
Grade: 7
Grade: 8
Grade: 9
Grade: 10
Grade: 11
Grade: 12
Grade: 13
Grade: 14
Grade: 15
Grade: 16
Grade: 17
Grade: 18
Grade: 19
Grade: 20
GPA: 10.5
Max: 20
Min: 1

# How to compile and link - Compling is entering a directory and typing "make". Cleaning past files is make clean.
