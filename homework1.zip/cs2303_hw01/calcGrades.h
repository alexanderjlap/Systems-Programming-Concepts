/**
 * @file calcGrade.h
 * @purpose Calculates GPA based on the grades entered 
 * on the command line
 * @author Alexander Lap
 * @version 1.0.0
 * date 2023-01-22
 */

#ifndef CALCGRADE_H
#define CALCGRADE_H

int calcGrades(int grades[], int numGrades);

#endif
